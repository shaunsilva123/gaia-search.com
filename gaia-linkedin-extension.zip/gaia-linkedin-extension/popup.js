// popup.js — handles scraping LinkedIn and saving to Supabase

const SUPABASE_URL = "https://wnzpeyrdtdxcodeezqxb.supabase.co";
const SUPABASE_KEY = "sb_publishable_nH49MFdJkjkc0GXTk_Z9rw_02yreXHN";

async function saveToSupabase(candidate) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/candidates`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Prefer": "return=representation"
    },
    body: JSON.stringify(candidate)
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || "Failed to save");
  }
  return res.json();
}

function showStatus(msg, type) {
  const el = document.getElementById("status");
  el.textContent = msg;
  el.className = "status " + type;
}

// Runs INSIDE the LinkedIn page
async function scrapeFromPage() {
  window.scrollTo(0, 0);
  await new Promise(r => setTimeout(r, 1000));

  // NAME
  const h1 = document.querySelector("h1");
  let name = h1 ? h1.innerText.trim() : "";
  name = name.replace(/\s*\|.*$/, "").replace(/\s*·.*$/, "").trim();
  if (!name) {
    name = document.title.replace(/\s*\|\s*LinkedIn\s*$/, "").split(" - ")[0].trim();
  }

  // LOCATION — declared early so it can be used in filtering below
  let location = "";
  const allEls = Array.from(document.querySelectorAll("*"));
  for (const el of allEls) {
    if (el.children.length > 0) continue;
    const txt = (el.innerText || el.textContent || "").trim();
    if (
      txt.length > 5 && txt.length < 80 &&
      txt.split(",").length >= 2 &&
      (
        txt.includes("United Kingdom") || txt.includes("England") ||
        txt.includes("Scotland") || txt.includes("Wales") ||
        txt.includes("Ireland") || txt.includes("United States") ||
        txt.includes("Australia") || txt.includes("Canada") ||
        txt.includes("Germany") || txt.includes("France") ||
        txt.includes("Netherlands") || txt.includes("Singapore") ||
        txt.includes("New Zealand") || txt.includes("South Africa") ||
        txt.includes("Italy") || txt.includes("Spain")
      )
    ) {
      location = txt;
      break;
    }
  }

  // HEADLINE & COMPANY — scan body text lines
  let headline = "";
  let company = "";

  // First try page title
  const cleanTitle = document.title.replace(/\s*\|\s*LinkedIn\s*$/, "").trim();
  if (cleanTitle.includes(" - ")) {
    const dashIdx = cleanTitle.indexOf(" - ");
    headline = cleanTitle.substring(dashIdx + 3).trim();
    if (headline.includes(" at ")) company = headline.split(" at ").pop().trim();
  }

  // Then scan body text lines for headline below name
  if (!headline) {
    const bodyText = document.body.innerText || "";
    const lines = bodyText.split("\n").map(l => l.trim()).filter(l => l.length > 0);
    const nameIdx = lines.findIndex(l =>
      l === name || l.startsWith(name + " ·") || l.startsWith(name + " •")
    );
    if (nameIdx >= 0) {
      const skipWords = ["connection","follower","contact info","message",
        "she/her","he/him","they/them","1st","2nd","3rd","view in","mutual"];
      for (let i = nameIdx + 1; i < Math.min(nameIdx + 8, lines.length); i++) {
        const line = lines[i];
        if (line.length < 5 || line.length > 300) continue;
        if (line.match(/^\d/)) continue;
        if (line.includes("·")) continue;
        if (line === location) continue;
        if (skipWords.some(w => line.toLowerCase().includes(w))) continue;
        headline = line;
        if (line.includes(" at ")) company = line.split(" at ").pop().trim();
        else if (line.includes(" - ")) company = line.split(" - ").pop().trim();
        else if (line.includes(" | ")) company = line.split(" | ").pop().trim();
        break;
      }
    }
  }

  // COMPANY fallback — /company/ links
  if (!company) {
    const links = document.querySelectorAll("a[href*='/company/']");
    for (const link of links) {
      const txt = (link.innerText || "").trim().split("\n")[0].trim();
      if (txt && txt.length > 1 && txt.length < 80 &&
          !txt.toLowerCase().includes("follow") &&
          !txt.toLowerCase().includes("see all")) {
        company = txt;
        break;
      }
    }
  }

  // EMAIL — click Contact info and grab from modal
  let email = "";
  try {
    const allLinks = Array.from(document.querySelectorAll("a, button, span, div"));
    const contactLink = allLinks.find(el =>
      (el.innerText || "").trim().toLowerCase() === "contact info"
    );
    if (contactLink) {
      contactLink.click();
      await new Promise(r => setTimeout(r, 1800));
      const match = document.body.innerText.match(
        /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/
      );
      if (match) email = match[0];
      const closeBtn = document.querySelector(
        "button[aria-label='Dismiss'], button[aria-label='Close'], .artdeco-modal__dismiss"
      );
      if (closeBtn) closeBtn.click();
    }
  } catch(e) {}

  if (!email) {
    const match = document.body.innerText.match(
      /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/
    );
    if (match) email = match[0];
  }

  const profileUrl = window.location.href.split("?")[0];
  return { name, headline, location, company, email, profileUrl };
}

function populateForm(data) {
  const profileCard = document.getElementById("profile-card");
  const form = document.getElementById("form");

  if (data && data.name) {
    profileCard.classList.add("visible");
    document.getElementById("p-name").textContent = data.name;
    document.getElementById("p-role").textContent = data.headline || "";
    document.getElementById("p-meta").textContent = data.location || "";
  }

  document.getElementById("f-name").value = (data && data.name) || "";
  document.getElementById("f-role").value = (data && data.headline) || "";
  document.getElementById("f-company").value = (data && data.company) || "";
  document.getElementById("f-location").value = (data && data.location) || "";
  document.getElementById("f-email").value = (data && data.email) || "";
  document.getElementById("f-notes").value = (data && data.profileUrl)
    ? "LinkedIn: " + data.profileUrl : "";

  form.style.display = "block";

  document.getElementById("btn-save").addEventListener("click", async () => {
    const btn = document.getElementById("btn-save");
    btn.disabled = true;
    btn.textContent = "Saving…";

    const companyVal = document.getElementById("f-company").value.trim();
    const notesVal = document.getElementById("f-notes").value.trim();

    const candidate = {
      name: document.getElementById("f-name").value.trim(),
      role: document.getElementById("f-role").value.trim(),
      location: document.getElementById("f-location").value.trim(),
      email: document.getElementById("f-email").value.trim(),
      status: document.getElementById("f-status").value,
      notes: [companyVal ? "Company: " + companyVal : "", notesVal]
        .filter(Boolean).join("\n"),
    };

    if (!candidate.name) {
      showStatus("Please enter a name.", "error");
      btn.disabled = false;
      btn.textContent = "Add to Gaia CRM";
      return;
    }

    try {
      await saveToSupabase(candidate);
      showStatus("✅ Added to Gaia CRM successfully!", "success");
      btn.textContent = "Added!";
    } catch (err) {
      showStatus("❌ Error: " + err.message, "error");
      btn.disabled = false;
      btn.textContent = "Add to Gaia CRM";
    }
  });
}

function init() {
  const loading = document.getElementById("loading");
  const notLinkedin = document.getElementById("not-linkedin");

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab.url || !tab.url.includes("linkedin.com/in/")) {
      loading.style.display = "none";
      notLinkedin.style.display = "block";
      return;
    }

    chrome.scripting.executeScript(
      { target: { tabId: tab.id }, func: scrapeFromPage, world: "MAIN" },
      (results) => {
        if (chrome.runtime.lastError || !results || !results[0]) {
          loading.style.display = "none";
          showStatus("Could not read page. Try refreshing LinkedIn.", "error");
          document.getElementById("form").style.display = "block";
          return;
        }
        const result = results[0].result;
        if (result && typeof result.then === "function") {
          result.then(data => {
            loading.style.display = "none";
            populateForm(data);
          });
        } else {
          loading.style.display = "none";
          populateForm(result);
        }
      }
    );
  });
}

document.addEventListener("DOMContentLoaded", init);
