// content.js — runs on LinkedIn profile pages

function scrapeProfile() {
  const body = document.body;

  // NAME — h1 is always the name on profile pages
  const h1 = body.querySelector("h1");
  const name = h1 ? h1.innerText.trim() : "";

  // HEADLINE — the div immediately after h1 containing the job title
  let headline = "";
  if (h1) {
    let el = h1.nextElementSibling;
    while (el) {
      const txt = el.innerText.trim();
      if (txt && txt.length > 3 && txt.length < 300 && !txt.includes("connection")) {
        headline = txt;
        break;
      }
      el = el.nextElementSibling;
    }
  }

  // LOCATION — look for text matching city/country pattern near top of page
  let location = "";
  const allSpans = Array.from(body.querySelectorAll("span"));
  for (const span of allSpans) {
    const txt = span.innerText.trim();
    if (
      txt.length > 3 && txt.length < 80 &&
      (txt.includes("United Kingdom") || txt.includes("England") ||
       txt.includes("Scotland") || txt.includes("Wales") ||
       txt.includes("Ireland") || txt.includes("United States") ||
       txt.includes("Australia") || txt.includes("Canada") ||
       (txt.includes(",") && txt.split(",").length <= 3 && !txt.includes("·")))
    ) {
      location = txt;
      break;
    }
  }

  // COMPANY — look for the company button/link near the top card
  let company = "";
  // Try aria-label on company links
  const companyLinks = body.querySelectorAll(
    "a[href*='/company/'] span[aria-hidden='true'], " +
    ".pv-text-details__right-panel a span, " +
    "[data-field='experience_company_logo'] ~ div span"
  );
  for (const el of companyLinks) {
    const txt = el.innerText.trim();
    if (txt && txt.length > 1 && txt.length < 60) {
      company = txt;
      break;
    }
  }

  // Fallback: extract from headline "at Company"
  if (!company && headline.includes(" at ")) {
    company = headline.split(" at ").pop().trim();
  }

  // Fallback: look for text near Ricardo plc style — visible company name
  if (!company) {
    const imgs = body.querySelectorAll("img[alt]");
    for (const img of imgs) {
      const alt = img.alt.trim();
      if (alt && alt.length > 2 && alt.length < 60 &&
          !alt.toLowerCase().includes("profile") &&
          !alt.toLowerCase().includes("photo") &&
          !alt.toLowerCase().includes("logo") &&
          img.closest("a[href*='/company/']")) {
        company = alt;
        break;
      }
    }
  }

  // EMAIL
  const emailMatch = body.innerText.match(
    /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/
  );
  const email = emailMatch ? emailMatch[0] : "";

  const profileUrl = window.location.href.split("?")[0];

  return { name, headline, location, company, email, profileUrl };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "scrape") {
    sendResponse(scrapeProfile());
  }
});

